package com.example.smart_gateway_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
