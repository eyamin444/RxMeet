// android/build.gradle.kts
allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
