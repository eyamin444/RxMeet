import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Api {
  static late Dio _dio;
  static late String _base;

  /// Initialize once at app start.
  ///
  /// Priority for base URL:
  /// 1) [override] parameter (if passed from code)
  /// 2) --dart-define=API_BASE_URL=...  (recommended)
  /// 3) Fallback "http://127.0.0.1:8000" (works with `adb reverse tcp:8000 tcp:8000`)
  static Future<void> init({String? override}) async {
    const env = String.fromEnvironment('API_BASE_URL');
    _base = override ??
        (env.isNotEmpty ? env : 'http://127.0.0.1:8000');

    _dio = Dio(
      BaseOptions(
        baseUrl: _base,
        connectTimeout: const Duration(seconds: 8),
        receiveTimeout: const Duration(seconds: 30),
        headers: {'Content-Type': 'application/json'},
      ),
    );

    // Attach auth header from SharedPreferences on every request.
    _dio.interceptors.add(
      InterceptorsWrapper(onRequest: (opt, handler) async {
        final prefs = await SharedPreferences.getInstance();
        final tok = prefs.getString('token');
        if (tok != null && tok.isNotEmpty) {
          opt.headers['Authorization'] = 'Bearer $tok';
        }
        handler.next(opt);
      }),
    );
  }

  static String get baseUrl => _base;

  // Token helpers
  static Future<void> setToken(String? token) async {
    final prefs = await SharedPreferences.getInstance();
    if (token == null || token.isEmpty) {
      await prefs.remove('token');
    } else {
      await prefs.setString('token', token);
    }
  }

  // Optional quick health check (expects FastAPI /ping -> {"ok":true})
  static Future<bool> ping() async {
    try {
      final res = await _dio.get('/ping');
      return res.statusCode == 200 &&
          res.data is Map &&
          (res.data['ok'] == true || res.data['status'] == 'ok');
    } catch (_) {
      return false;
    }
  }

  // HTTP helpers
  static Future<dynamic> get(String path, {Map<String, dynamic>? query}) async {
    final res = await _dio.get(path, queryParameters: query);
    return res.data;
  }

  static Future<Uint8List> getBytes(String path, {Map<String, dynamic>? query}) async {
    final res = await _dio.get<List<int>>(
      path,
      queryParameters: query,
      options: Options(responseType: ResponseType.bytes),
    );
    return Uint8List.fromList(res.data ?? const <int>[]);
  }

  static Future<dynamic> post(
    String path, {
    dynamic data,
    bool multipart = false,
    bool formUrlEncoded = false,
  }) async {
    final res = await _dio.post(
      path,
      data: data,
      options: multipart
          ? Options(contentType: 'multipart/form-data')
          : formUrlEncoded
              ? Options(contentType: Headers.formUrlEncodedContentType)
              : null,
    );
    return res.data;
  }

  static Future<dynamic> patch(String path, {dynamic data}) async {
    final res = await _dio.patch(path, data: data);
    return res.data;
  }

  static Future<dynamic> put(String path, {dynamic data, Map<String, dynamic>? query}) async {
    final res = await _dio.put(path, data: data, queryParameters: query);
    return res.data;
  }

  static Future<dynamic> delete(String path, {Map<String, dynamic>? query}) async {
    final res = await _dio.delete(path, queryParameters: query);
    return res.data;
  }
}
