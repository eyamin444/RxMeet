class Env {
  // === Ctrl+F anchors (replace once, propagate everywhere) ===
  static const apiBase      = 'http://localhost:8000';         // TODO_API_BASE
  static const mintEndpoint = '/appointments/{id}/video/token';// TODO_MINT_PATH
  // Your app should already manage a bearer token; inject it where noted
}
