package com.example.rxmeet

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
