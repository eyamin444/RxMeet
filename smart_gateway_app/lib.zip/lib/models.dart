class User {
  final int id;
  final String name;
  final String? email;
  final String? phone;
  final String role;
  final String? photoPath;

  User({
    required this.id,
    required this.name,
    this.email,
    this.phone,
    required this.role,
    this.photoPath,
  });

  factory User.fromJson(Map<String, dynamic> j) => User(
        id: j['id'] as int,
        name: j['name'] as String,
        email: j['email'] as String?,
        phone: j['phone'] as String?,
        role: j['role'] as String,
        photoPath: j['photo_path'] as String?,
      );
}


class Doctor {
  final int id;
  final String name;
  final String? email;
  final String specialty;
  final String category;
  final String keywords;
  final String bio;
  final String background;
  final int rating;
  final String? photoPath;

  Doctor({
    required this.id,
    required this.name,
    this.email,
    required this.specialty,
    required this.category,
    required this.keywords,
    required this.bio,
    required this.background,
    required this.rating,
    this.photoPath,
  });

  factory Doctor.fromJson(Map<String, dynamic> j) => Doctor(
        id: j['id'] as int,
        name: j['name'] as String,
        email: j['email'] as String?,
        specialty: (j['specialty'] ?? '') as String,
        category: (j['category'] ?? 'General') as String,
        keywords: (j['keywords'] ?? '') as String,
        bio: (j['bio'] ?? '') as String,
        background: (j['background'] ?? '') as String,
        rating: (j['rating'] ?? 0) as int,
        photoPath: j['photo_path'] as String?,
      );
}


class Appointment {
  final int id;
  final int doctorId;
  final int patientId;
  final DateTime start;
  final DateTime end;
  final String status;
  final String paymentStatus;
  final String visitMode;
  final String patientProblem;
  final String progress;
  final String? videoRoom;

  Appointment({
    required this.id,
    required this.doctorId,
    required this.patientId,
    required this.start,
    required this.end,
    required this.status,
    required this.paymentStatus,
    required this.visitMode,
    required this.patientProblem,
    required this.progress,
    this.videoRoom,
  });

  factory Appointment.fromJson(Map<String, dynamic> j) => Appointment(
        id: j['id'] as int,
        doctorId: j['doctor_id'] as int,
        patientId: j['patient_id'] as int,
        start: DateTime.parse(j['start_time'] as String),
        end: DateTime.parse(j['end_time'] as String),
        status: j['status'] as String,
        paymentStatus: j['payment_status'] as String,
        visitMode: (j['visit_mode'] ?? 'offline') as String,
        patientProblem: (j['patient_problem'] ?? '') as String,
        progress: (j['progress'] ?? 'not_yet') as String,
        videoRoom: j['video_room'] as String?,
      );
}

class _MedRow {
  final int id;
  String name;
  String dose;
  String form;
  String frequency;
  String duration;
  String notes;

  _MedRow({
    required this.id,
    this.name = '',
    this.dose = '',
    this.form = '',
    this.frequency = '',
    this.duration = '',
    this.notes = '',
  });
}

