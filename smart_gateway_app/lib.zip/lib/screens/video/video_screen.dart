import 'package:flutter/material.dart';

class VideoScreen extends StatelessWidget {
  const VideoScreen({super.key, required this.room});
  final String room;

  @override
  Widget build(BuildContext context) {
    // Placeholder: display room string. You can integrate WebRTC later.
    return Scaffold(
      appBar: AppBar(title: const Text('Video Call')),
      body: Center(
        child: SelectableText('Join room: $room',
            style: Theme.of(context).textTheme.headlineSmall),
      ),
    );
  }
}
