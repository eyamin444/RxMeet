\
import 'dart:typed_data';
import 'dart:io' show File, Platform;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

/// Download arbitrary bytes with a suggested filename.
/// - Web: triggers a browser download via an anchor.
/// - Android/iOS: saves to app files and shows a share sheet so user can Save/Open.
Future<void> downloadBytes(Uint8List bytes, String suggestedName) async {
  if (kIsWeb) {
    // ignore: avoid_web_libraries_in_flutter
    import 'dart:html' as html;
    final blob = html.Blob([bytes]);
    final url = html.Url.createObjectUrlFromBlob(blob);
    final a = html.AnchorElement(href: url)..download = suggestedName;
    html.document.body?.append(a);
    a.click();
    a.remove();
    html.Url.revokeObjectUrl(url);
    return;
  }

  final dir = await getTemporaryDirectory();
  final file = File('${dir.path}/$suggestedName');
  await file.writeAsBytes(bytes);
  await Share.shareXFiles([XFile(file.path)]);
}

/// Open a URL in external browser (or default handler).
Future<void> openUrlExternal(String url) async {
  final uri = Uri.parse(url);
  if (!await canLaunchUrl(uri)) {
    throw 'Cannot open $url';
  }
  await launchUrl(uri, mode: LaunchMode.externalApplication);
}
