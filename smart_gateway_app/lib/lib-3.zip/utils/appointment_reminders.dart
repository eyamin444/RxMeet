import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import '../main.dart' show notifications;

const _channelId = 'appointments';
const _channelName = 'Appointment Reminders';

Future<void> scheduleAppointmentReminders({
  required int appointmentId,
  required DateTime appointmentStartLocal,
  required String patientName,
}) async {
  const android = AndroidNotificationDetails(
    _channelId, _channelName,
    importance: Importance.high,
    priority: Priority.high,
  );
  const details = NotificationDetails(android: android);

  final oneDayBefore  = appointmentStartLocal.subtract(const Duration(days: 1));
  final oneHourBefore = appointmentStartLocal.subtract(const Duration(hours: 1));

  Future<void> _schedule(int id, DateTime when, String body) async {
    if (when.isAfter(DateTime.now())) {
      await notifications.zonedSchedule(
        id,
        'Appointment Reminder',
        body,
        tz.TZDateTime.from(when, tz.local),
        details,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      );
    }
  }

  await _schedule(
    appointmentId * 10 + 1,
    oneDayBefore,
    'Hi $patientName, your appointment is tomorrow at '
    '${appointmentStartLocal.hour.toString().padLeft(2, '0')}:'
    '${appointmentStartLocal.minute.toString().padLeft(2, '0')}',
  );

  await _schedule(
    appointmentId * 10 + 2,
    oneHourBefore,
    'Hi $patientName, your appointment starts in 1 hour.',
  );
}

Future<void> cancelAppointmentReminders(int appointmentId) async {
  await notifications.cancel(appointmentId * 10 + 1);
  await notifications.cancel(appointmentId * 10 + 2);
}
