// lib/screens/doctor/dashboard.dart
//
// Doctor dashboard (tabs: Appointments, Patients, Schedule, Profile)
//
// ✅ Appointments tab with filters & sorting
// ✅ Schedule tab: list weekly/date rules with ON/OFF, inline edit, delete,
//    sorting options, and created-at shown via tooltip (no inline text for weekly)
// ✅ Daily create form has its own maxPatients/mode (sent as `mode` to API)
// ✅ Patients and Profile tabs
// ✅ Appointment detail: progress + TEXT PRESCRIPTION composer with preview
//    (pad-style), per-appointment list (text/file) with open/zoom + delete,
//    edit allowed until 24h after completed. File delete fixed.
// ✅ Photo upload fixed for web/mobile with clear UX

import 'dart:typed_data';

import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../main.dart' show LoginPage; // for logout navigation
import '../../models.dart';
import '../../services/api.dart';
import '../../services/auth.dart';

// ====== helpers

String fmtSlot(DateTime s, DateTime e) =>
    '${DateFormat.MMMd().format(s)}  ${DateFormat.Hm().format(s)} - ${DateFormat.Hm().format(e)}';

String labelize(String s) => s.replaceAll('_', ' ');

const _chipPadding = EdgeInsets.symmetric(horizontal: 8, vertical: 4);

const List<String> kProgressOrder = [
  'not_yet',
  'in_progress',
  'hold',
  'completed',
  'no_show',
];

class _Pill extends StatelessWidget {
  final String text;
  const _Pill(this.text);
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: _chipPadding,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(text, style: const TextStyle(fontSize: 12)),
    );
  }
}

// Robust file picker for web/mobile with clear errors
Future<MultipartFile?> _pickMultipartFile({
  List<String>? allowedExtensions,
  FileType? type, // nullable so we can decide when to use custom
  String fieldName = 'file',
}) async {
  try {
    final useCustom = allowedExtensions != null && allowedExtensions.isNotEmpty;
    final res = await FilePicker.platform.pickFiles(
      type: useCustom ? FileType.custom : (type ?? FileType.any),
      allowedExtensions: allowedExtensions,
      withData: true, // important for web
    );
    if (res == null || res.files.isEmpty) return null;
    final f = res.files.single;
    if (f.bytes != null) {
      return MultipartFile.fromBytes(
        f.bytes as Uint8List,
        filename: f.name,
      );
    }
    if (f.path != null) {
      return MultipartFile.fromFile(
        f.path!,
        filename: f.name,
      );
    }
    return null;
  } catch (e) {
    throw Exception('File pick failed: $e');
  }
}

// Turn any relative-ish path into absolute
String _absUrlFromString(String? maybePathOrUrl) {
  if (maybePathOrUrl == null || maybePathOrUrl.isEmpty) return '';
  if (maybePathOrUrl.startsWith('http')) return maybePathOrUrl;
  final path = maybePathOrUrl.startsWith('/') ? maybePathOrUrl : '/$maybePathOrUrl';
  return '${Api.baseUrl}$path';
}

String? _absUrlFromMap(Map<String, dynamic> m) {
  final candidates = [
    m['file_url']?.toString(),
    m['url']?.toString(),
    m['file_path']?.toString(),
    m['path']?.toString(),
  ];
  for (final c in candidates) {
    if (c != null && c.toString().isNotEmpty) {
      final s = c.toString();
      if (s.startsWith('http')) return s;
      return '${Api.baseUrl}${s.startsWith('/') ? s : '/$s'}';
    }
  }
  return null;
}

bool _looksLikeImage(String url) {
  final lower = url.toLowerCase();
  return lower.endsWith('.png') || lower.endsWith('.jpg') || lower.endsWith('.jpeg') || lower.endsWith('.webp') || lower.endsWith('.gif');
}
//// === START ADD: prescription url helpers ===

// Detect text/file type (fallbacks to 'text')
String _rxType(Map<String, dynamic> p) {
  final t = (p['type'] ?? p['kind'] ?? '').toString();
  if (t.isNotEmpty) return t;
  // crude but useful: if there is a content field -> text
  if ((p['content'] ?? '').toString().isNotEmpty ||
      (p['data'] is Map && (p['data']['diagnosis'] != null || p['data']['medicines'] != null))) {
    return 'text';
  }
  return 'file';
}

// Extract *any* usable URL from varied API shapes.
String? _rxFileUrl(Map<String, dynamic> p) {
  // flat keys first
  final flatCandidates = [
    p['file_url'],
    p['pdf_url'],
    p['url'],
    p['file_path'],
    p['path'],
    p['file'], // some APIs return { file: "https://..." }
  ].whereType<String>().toList();

  for (final s in flatCandidates) {
    if (s.trim().isEmpty) continue;
    if (s.startsWith('http')) return s.trim();
    // relative → absolute
    return '${Api.baseUrl}${s.startsWith('/') ? s : '/$s'}';
  }

  // nested: data.file_url / data.url / data.pdf_url
  final data = (p['data'] is Map) ? (p['data'] as Map).cast<String, dynamic>() : null;
  if (data != null) {
    for (final k in ['file_url', 'pdf_url', 'url', 'path']) {
      final v = data[k]?.toString();
      if (v != null && v.trim().isNotEmpty) {
        if (v.startsWith('http')) return v.trim();
        return '${Api.baseUrl}${v.startsWith('/') ? v : '/$v'}';
      }
    }
  }
  return null;
}

//// === END ADD: prescription url helpers ===

// ====== main screen

class DoctorDashboard extends StatefulWidget {
  const DoctorDashboard({super.key, required this.me});
  final User me;

  @override
  State<DoctorDashboard> createState() => _DoctorDashboardState();
}

class _DoctorDashboardState extends State<DoctorDashboard>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs = TabController(length: 4, vsync: this);

  Future<void> _logout() async {
    try {
      await AuthService.logout();
    } catch (_) {}
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (r) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Doctor Dashboard'),
        actions: [
          IconButton(icon: const Icon(Icons.logout), onPressed: _logout),
        ],
        bottom: TabBar(
          controller: _tabs,
          isScrollable: true,
          tabs: const [
            Tab(text: 'Appointments'),
            Tab(text: 'Patients'),
            Tab(text: 'Schedule'),
            Tab(text: 'Profile'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabs,
        children: const [
          _AppointmentsTab(),
          PatientsTab(),
          ScheduleTab(),
          ProfileTab(),
        ],
      ),
    );
  }
}

// ====== models for UI

class _Appt {
  final int id, doctorId, patientId;
  final DateTime start, end;
  final String status, progress, visitMode, patientName;
  final String? videoRoom;

  _Appt.fromJson(Map<String, dynamic> j)
      : id = (j['id'] as num).toInt(),
        doctorId = (j['doctor_id'] as num).toInt(),
        patientId = (j['patient_id'] as num).toInt(),
        start = DateTime.parse(j['start_time'].toString()),
        end = DateTime.parse(j['end_time'].toString()),
        status = (j['status'] ?? '').toString(),
        progress = (() {
          final raw = j['progress'];
          if (raw is int) {
            final idx = raw.clamp(0, kProgressOrder.length - 1);
            return kProgressOrder[idx];
          }
          return (raw ?? 'not_yet').toString();
        })(),
        visitMode = (j['visit_mode'] ?? 'offline').toString(),
        patientName = (j['patient_name'] ?? '').toString(),
        videoRoom = j['video_room']?.toString();
}

// ====== Appointments tab (unified)

class _AppointmentsTab extends StatefulWidget {
  const _AppointmentsTab();
  @override
  State<_AppointmentsTab> createState() => _AppointmentsTabState();
}

class _AppointmentsTabState extends State<_AppointmentsTab> {
  List<_Appt> all = [];
  bool loading = true;

  // Filters
  String statusFilter = 'all'; // all|pending|approved|cancelled
  String progressFilter = 'all'; // all|kProgressOrder...
  DateTimeRange? range;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final views = ['today', 'pending', 'upcoming', 'completed'];
      final List<_Appt> acc = [];
      for (final v in views) {
        final r = await Api.get('/doctor/appointments', query: {'view': v});
        final list = (r as List)
            .map((e) => _Appt.fromJson((e as Map).cast<String, dynamic>()))
            .toList();
        acc.addAll(list);
      }
      final map = <int, _Appt>{for (final a in acc) a.id: a};
      final now = DateTime.now();
      int score(_Appt a) {
        final isToday = a.start.year == now.year &&
            a.start.month == now.month &&
            a.start.day == now.day;
        final isCompleted = a.progress == 'completed';
        return (isToday ? 0 : 1) * 100000000 +
            (isCompleted ? 2 : 1) * 1000000 +
            a.start.millisecondsSinceEpoch;
      }

      final sorted = map.values.toList()
        ..sort((a, b) => score(a).compareTo(score(b)));

      if (!mounted) return;
      setState(() {
        all = sorted;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Load failed: $e')));
    }
  }

  List<_Appt> get filtered {
    Iterable<_Appt> it = all;
    if (statusFilter != 'all') {
      it = it.where((a) => a.status == statusFilter);
    }
    if (progressFilter != 'all') {
      it = it.where((a) => a.progress == progressFilter);
    }
    if (range != null) {
      it = it.where((a) =>
          a.start.isAfter(range!.start.subtract(const Duration(minutes: 1))) &&
          a.start.isBefore(range!.end.add(const Duration(minutes: 1))));
    }
    return it.toList();
  }

  Future<void> _pickRange() async {
    final now = DateTime.now();
    final res = await showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 2),
      initialDateRange: range ??
          DateTimeRange(
            start: DateTime(now.year, now.month, now.day),
            end: DateTime(now.year, now.month, now.day),
          ),
    );
    if (res != null) setState(() => range = res);
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      // Filters row
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
        child: Wrap(
          spacing: 8,
          runSpacing: 8,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            DropdownButton<String>(
              value: statusFilter,
              items: const [
                DropdownMenuItem(value: 'all', child: Text('Status: All')),
                DropdownMenuItem(value: 'pending', child: Text('Pending')),
                DropdownMenuItem(value: 'approved', child: Text('Approved')),
                DropdownMenuItem(value: 'cancelled', child: Text('Cancelled')),
              ],
              onChanged: (v) => setState(() => statusFilter = v ?? 'all'),
            ),
            DropdownButton<String>(
              value: progressFilter,
              items: const [
                DropdownMenuItem(value: 'all', child: Text('Progress: All')),
                DropdownMenuItem(value: 'not_yet', child: Text('Not yet')),
                DropdownMenuItem(value: 'in_progress', child: Text('In progress')),
                DropdownMenuItem(value: 'hold', child: Text('Hold')),
                DropdownMenuItem(value: 'completed', child: Text('Completed')),
                DropdownMenuItem(value: 'no_show', child: Text('No show')),
              ],
              onChanged: (v) => setState(() => progressFilter = v ?? 'all'),
            ),
            FilledButton.tonal(
              onPressed: _pickRange,
              child: Text(range == null
                  ? 'Pick date'
                  : '${DateFormat.yMMMd().format(range!.start)} → ${DateFormat.yMMMd().format(range!.end)}'),
            ),
            const SizedBox(width: 8),
            IconButton(
              onPressed: () => setState(() => range = null),
              icon: const Icon(Icons.close),
              tooltip: 'Clear date',
            ),
            const SizedBox(width: 16),
            IconButton(
              onPressed: _load,
              icon: const Icon(Icons.refresh),
              tooltip: 'Refresh',
            ),
          ],
        ),
      ),
      const SizedBox(height: 8),
      Expanded(
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : filtered.isEmpty
                ? const Center(child: Text('No appointments'))
                : RefreshIndicator(
                    onRefresh: _load,
                    child: ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      itemCount: filtered.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (ctx, i) {
                        final a = filtered[i];
                        return ListTile(
                          onTap: () => Navigator.of(context).push(MaterialPageRoute(
                              builder: (_) => AppointmentDetail(apptId: a.id, onChanged: _load))),
                          title: Text(a.patientName.isEmpty ? 'Patient #${a.patientId}' : a.patientName),
                          subtitle: Text('${fmtSlot(a.start, a.end)} • ${a.visitMode.toUpperCase()}'),
                          trailing: Wrap(
                            spacing: 6,
                            runSpacing: 4,
                            children: [
                              _Pill(a.status),
                              _Pill('progress: ${labelize(a.progress)}'),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
      ),
    ]);
  }
}

// ====== appointment detail  (UPDATED WITH TEXT PRESCRIPTION + PREVIEW + LOCKS)
//// === START REPLACE: AppointmentDetail ===

class AppointmentDetail extends StatefulWidget {
  const AppointmentDetail({super.key, required this.apptId, required this.onChanged});
  final int apptId;
  final VoidCallback onChanged;
  @override
  State<AppointmentDetail> createState() => _AppointmentDetailState();
}

class _AppointmentDetailState extends State<AppointmentDetail> {
  Map<String, dynamic>? appt;
  String? progressVal;
  String? initialProgress; // server value to enforce 24h lock after 'completed'

  // list scoped to THIS appointment
  List<Map<String, dynamic>> apptPrescriptions = [];
  List<Map<String, dynamic>> apptReports = [];

  bool get canChangeProgress =>
    !((initialProgress ?? '') == 'completed' && !_within24hAfterCompleted);

  // text Rx composer
  bool showComposer = false;
  String diagnosis = '';
  String advice = '';
  DateTime? followUp;
  List<_MedRow> meds = [ _MedRow() ];
  bool editing = false;
  int? editingId;

  // file upload (separate section, not inside composer)
  MultipartFile? _rxFile;

  // profiles for pad header
  Map<String, dynamic>? patientProfile;
  Map<String, dynamic>? doctorProfile;

  // lock
  DateTime? completedAt;

  @override
  void initState() {
    super.initState();
    _loadAll();
  }

  Future<void> _loadAll() async {
    // appointment
    final r = await Api.get('/appointments/${widget.apptId}');
    final j = (r as Map).cast<String, dynamic>();

    final prog = (() {
      final raw = j['progress'];
      if (raw is int) {
        final idx = (raw as int).clamp(0, kProgressOrder.length - 1);
        return kProgressOrder[idx];
      }
      return (raw ?? 'not_yet').toString();
    })();

    DateTime? _ts(dynamic x) {
      final s = (x ?? '').toString();
      if (s.isEmpty) return null;
      try { return DateTime.parse(s); } catch (_) { return null; }
    }

    setState(() {
      appt = j;
      progressVal = prog;
      initialProgress = prog;
      completedAt = _ts(j['completed_at']) ?? _ts(j['progress_changed_at']) ?? _ts(j['updated_at']) ?? _ts(j['created_at']);
    });

    // patient + doctor profiles
    try {
      final pid = (j['patient_id'] as num).toInt();
      final pat = await Api.get('/patients/$pid');
      patientProfile = (pat as Map).cast<String, dynamic>();
    } catch (_) {}
    try {
      final me = await Api.get('/doctor/me');
      doctorProfile = (me as Map).cast<String, dynamic>();
    } catch (_) {}

    await Future.wait([_loadApptPrescriptions(), _loadApptReports()]);
    if (mounted) setState(() {});
  }

  Future<void> _loadApptPrescriptions() async {
    try {
      final rx = await Api.get('/appointments/${widget.apptId}/prescriptions');
      apptPrescriptions =
          (rx as List).map((e) => (e as Map).cast<String, dynamic>()).toList()
            ..sort((a,b)=> (b['created_at']??'').toString().compareTo((a['created_at']??'').toString()));
    } catch (_) {
      try {
        final rx = await Api.get('/appointments/${widget.apptId}/prescription');
        if (rx is Map && rx.isNotEmpty) {
          apptPrescriptions = [rx.cast<String, dynamic>()];
        }
      } catch (_) {}
    }
    if (mounted) setState((){});
  }

  Future<void> _loadApptReports() async {
    try {
      final rr = await Api.get('/appointments/${widget.apptId}/reports');
      apptReports =
          (rr as List).map((e) => (e as Map).cast<String, dynamic>()).toList()
            ..sort((a,b)=> (b['created_at']??'').toString().compareTo((a['created_at']??'').toString()));
    } catch (_) {
      apptReports = [];
    }
  }

  // ----- progress + lock

  bool get _within24hAfterCompleted {
    if ((progressVal ?? '') != 'completed') return true; // not completed -> editable
    if (completedAt == null) return false;
    return DateTime.now().difference(completedAt!).inHours < 24;
  }

  bool get canEdit => _within24hAfterCompleted;

 //// === START REPLACE: _updateProgress ===
Future<void> _updateProgress() async {
  if (progressVal == null || progressVal!.isEmpty) {
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Choose a progress value')));
    return;
  }

  // If appointment is already 'completed' and >24h passed, block any change.
  if ((initialProgress ?? '') == 'completed' && !_within24hAfterCompleted) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Progress is locked (completed > 24h).')),
    );
    return;
  }

  try {
    await Api.patch('/appointments/${widget.apptId}/progress',
        data: FormData.fromMap({'progress': progressVal}));
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Progress updated')));
    await _loadAll(); // refresh -> updates initialProgress + completedAt
    widget.onChanged();
  } on DioException catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('HTTP ${e.response?.statusCode}: ${e.response?.data}')));
  }
}
//// === END REPLACE: _updateProgress ===

  // ----- text prescription payload

  Map<String, dynamic> _textPayload() {
    return {
      'diagnosis': diagnosis.trim(),
      'advice': advice.trim(),
      'follow_up': followUp == null ? null : DateFormat('yyyy-MM-dd').format(followUp!),
      'medicines': meds
          .where((m) => m.name.trim().isNotEmpty)
          .map((m) => {
                'name': m.name.trim(),
                'dose': m.dose.trim(),
                'form': m.form.trim(),
                'frequency': m.frequency.trim(),
                'duration': m.duration.trim(),
                'notes': m.notes.trim(),
              })
          .toList(),
    };
  }

  bool get _textValid {
    final hasAnyMed = meds.any((m) => m.name.trim().isNotEmpty);
    return hasAnyMed || diagnosis.trim().isNotEmpty || advice.trim().isNotEmpty;
  }

  Future<void> _saveTextPrescription() async {
    if (!canEdit) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Editing locked (completed > 24h).')));
      return;
    }
    if (!_textValid) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Add medicine or fill diagnosis/advice.')));
      return;
    }
    try {
      if (editing && editingId != null) {
        await Api.patch('/appointments/${widget.apptId}/prescriptions/$editingId/text', data: _textPayload());
      } else {
        await Api.post('/appointments/${widget.apptId}/prescriptions/text', data: _textPayload());
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved')));
      editing = false;
      editingId = null;
      await _loadApptPrescriptions();
      setState(() => showComposer = false);
    } on DioException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('HTTP ${e.response?.statusCode}: ${e.response?.data}')));
    }
  }

  Future<void> _deleteTextPrescription(int id) async {
    if (!canEdit) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Editing locked (completed > 24h).')));
      return;
    }
    try {
      await Api.delete('/appointments/${widget.apptId}/prescriptions/$id');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Deleted')));
      await _loadApptPrescriptions();
    } on DioException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('HTTP ${e.response?.statusCode}: ${e.response?.data}')));
    }
  }

  Future<void> _deleteFilePrescription(int id) async {
    if (!canEdit) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Editing locked (completed > 24h).')));
      return;
    }
    try {
      try {
        await Api.delete('/appointments/${widget.apptId}/prescriptions/$id');
      } on DioException {
        await Api.delete('/prescriptions/$id');
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Deleted')));
      await _loadApptPrescriptions();
    } on DioException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('HTTP ${e.response?.statusCode}: ${e.response?.data}')));
    }
  }

  void _startEdit(Map<String, dynamic> p) {
    final data = (p['data'] as Map?)?.cast<String, dynamic>() ?? {};
    diagnosis = (data['diagnosis'] ?? '').toString();
    advice = (data['advice'] ?? '').toString();
    final fu = data['follow_up']?.toString();
    followUp = (fu == null || fu.isEmpty) ? null : DateTime.tryParse(fu);
    final medsList = (data['medicines'] as List?) ?? const [];
    meds = medsList.map((e) {
      final m = (e as Map).cast<String, dynamic>();
      return _MedRow(
        name: m['name']?.toString() ?? '',
        dose: m['dose']?.toString() ?? '',
        form: m['form']?.toString() ?? '',
        frequency: m['frequency']?.toString() ?? '',
        duration: m['duration']?.toString() ?? '',
        notes: m['notes']?.toString() ?? '',
      );
    }).toList();
    if (meds.isEmpty) meds = [ _MedRow() ];
    editing = true;
    editingId = (p['id'] as num?)?.toInt();
    setState(() {
      showComposer = true;
    });
  }

  // file upload (SEPARATE SECTION)
  Future<void> _attachRxFile() async {
    final f = await _pickMultipartFile(
      type: null,
      allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png', 'webp'],
    );
    if (f != null) setState(() => _rxFile = f);
  }

//// === START REPLACE: _uploadFilePrescription (replace older files first) ===
Future<void> _uploadFilePrescription() async {
  if (!canEdit) {
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Editing locked (completed > 24h).')));
    return;
  }
  if (_rxFile == null) {
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Attach a file first')));
    return;
  }
  try {
    // 1) Delete ALL existing file-type prescriptions for this appointment to "replace"
    final fileIds = apptPrescriptions
        .where((p) => _rxType(p) == 'file')
        .map((p) =>
            (p['id'] as num?)?.toInt() ??
            int.tryParse((p['id'] ?? p['prescription_id'] ?? '').toString()))
        .whereType<int>()
        .toList();

    for (final id in fileIds) {
      try {
        await Api.delete('/appointments/${widget.apptId}/prescriptions/$id');
      } on DioException {
        // fallback shape
        await Api.delete('/prescriptions/$id');
      }
    }

    // 2) Upload the new file
    try {
      await Api.post('/appointments/${widget.apptId}/prescription',
          data: FormData.fromMap({'file': _rxFile!}), multipart: true);
    } on DioException catch (e) {
      final code = e.response?.statusCode ?? 0;
      if (code == 404 || code == 405) {
        await Api.post('/appointments/${widget.apptId}/prescriptions/file',
            data: FormData.fromMap({'file': _rxFile!}), multipart: true);
      } else {
        rethrow;
      }
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Saved file prescription')));
    _rxFile = null;
    await _loadApptPrescriptions();
    setState(() {});
  } on DioException catch (e) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('HTTP ${e.response?.statusCode}: ${e.response?.data}')),
    );
  }
}
//// === END REPLACE: _uploadFilePrescription (replace older files first) ===


  @override
  Widget build(BuildContext context) {
    final j = appt;
    if (j == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final s = DateTime.parse(j['start_time'].toString());
    final e = DateTime.parse(j['end_time'].toString());
    final pid = (j['patient_id'] as num).toInt();
    final visitMode = (j['visit_mode'] ?? 'offline').toString();
    final videoRoom = j['video_room']?.toString();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Appointment'),
        actions: [
          if (visitMode == 'online') ...[
            TextButton.icon(
              onPressed: (videoRoom == null || videoRoom.isEmpty)
                  ? null
                  : () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => VideoCallPage(roomUrl: videoRoom)),
                      ),
              icon: const Icon(Icons.videocam, size: 18),
              label: const Text('Video'),
            ),
            const SizedBox(width: 4),
            TextButton.icon(
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => ChatPage(patientId: pid, apptId: widget.apptId)),
              ),
              icon: const Icon(Icons.chat_bubble_outline, size: 18),
              label: const Text('Chat'),
            ),
          ],
          TextButton.icon(
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => PatientProfilePage(patientId: pid)),
            ),
            icon: const Icon(Icons.person, size: 18),
            label: const Text('Patient'),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          // IDs & meta
          Text('Patient ID: $pid • Appointment ID: ${widget.apptId}',
              style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 4),
          Text((j['patient_name'] ?? 'Patient #$pid').toString(),
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          Text('${fmtSlot(s, e)} • ${visitMode.toUpperCase()}'),
          const SizedBox(height: 8),
          Wrap(spacing: 6, runSpacing: 4, children: [
            _Pill('status: ${j['status']}'),
            _Pill('progress: ${labelize(progressVal ?? 'not_yet')}'),
          ]),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: progressVal,
                  items: kProgressOrder
                      .map((v) => DropdownMenuItem(value: v, child: Text(labelize(v))))
                      .toList(),
                  onChanged: (v) => setState(() => progressVal = v),
                  decoration: const InputDecoration(labelText: 'Update progress'),
                ),
              ),
              const SizedBox(width: 12),
              FilledButton.icon(
                onPressed: canChangeProgress ? _updateProgress : null,
                icon: const Icon(Icons.save),
                label: const Text('Save'),
                ),
            ],
          ),

          const Divider(height: 32),

          // ===== PRESCRIPTIONS =====
          Row(
            children: [
              Text('Prescriptions', style: Theme.of(context).textTheme.titleMedium),
              const Spacer(),
              FilledButton.tonal(
                onPressed: !canEdit
                    ? null
                    : () {
                        diagnosis = '';
                        advice = '';
                        followUp = null;
                        meds = [ _MedRow() ];
                        editing = false;
                        editingId = null;
                        setState(() => showComposer = !showComposer);
                      },
                child: Text(showComposer ? 'Close' : 'Text prescription'),
              ),
            ],
          ),
          const SizedBox(height: 8),

          if (showComposer) _composerCard(),

          // ---- FILE PRESCRIPTION (outside composer)
          const SizedBox(height: 8),
          Text('Upload file prescription', style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 6),
    Row(
    children: [
        OutlinedButton.icon(
        onPressed: canEdit ? _attachRxFile : null,
        icon: const Icon(Icons.attach_file),
        label: Text(_rxFile == null ? 'Attach file' : '1 file attached'),
        ),
        const Spacer(),
        FilledButton(
        onPressed: canEdit ? _uploadFilePrescription : null,
        child: const Text('Upload'),
        ),
    ],
    ),
    if (!canEdit)
    Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Text(
        'Locked because progress is Completed for more than 24 hours.',
        style: Theme.of(context).textTheme.bodySmall,
        ),
    ),

          const Divider(height: 32),

          if (apptPrescriptions.isEmpty && !showComposer)
            const Text('No prescriptions yet for this appointment.',
                style: TextStyle(color: Colors.black54))
          else
            ...apptPrescriptions.map(_prescriptionTile),

          const Divider(height: 32),

          // ===== REPORTS =====
          Text('Reports for this appointment',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (apptReports.isEmpty)
            const Text('No reports for this appointment.')
          else
            ...apptReports.map((r) {
              final url = _absUrlFromMap(r);
              final title = (r['title'] ?? r['name'] ?? 'Report').toString();
              final created = (r['created_at'] ?? '').toString();
              return Card(
                child: ListTile(
                  leading: const Icon(Icons.insert_drive_file_outlined),
                  title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(created),
                  onTap: url == null ? null : () async {
                    if (_looksLikeImage(url)) {
                      showDialog(
                        context: context,
                        builder: (_) => Dialog(
                          clipBehavior: Clip.antiAlias,
                          child: InteractiveViewer(
                            minScale: 0.5, maxScale: 4,
                            child: Image.network(url, fit: BoxFit.contain),
                          ),
                        ),
                      );
                    } else {
                      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
                    }
                  },
                ),
              );
            }),
        ],
      ),
    );
  }

  // --- UI bits

  Widget _composerCard() {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Text(editing ? 'Edit text prescription' : 'New text prescription',
                  style: Theme.of(context).textTheme.titleSmall),
            ),
            const SizedBox(height: 8),
            TextField(
              decoration: const InputDecoration(labelText: 'Diagnosis', border: OutlineInputBorder()),
              minLines: 1, maxLines: 3,
              controller: TextEditingController(text: diagnosis),
              onChanged: (v) => diagnosis = v,
            ),
            const SizedBox(height: 10),
            _medicinesEditor(),
            const SizedBox(height: 10),
            TextField(
              decoration: const InputDecoration(labelText: 'Advice / Instructions', border: OutlineInputBorder()),
              minLines: 2, maxLines: 5,
              controller: TextEditingController(text: advice),
              onChanged: (v) => advice = v,
            ),
            const SizedBox(height: 10),
            _followUpRow(),
            const SizedBox(height: 8),
            Row(
              children: [
                OutlinedButton.icon(
                  onPressed: () {
                    final payload = _textPayload();
                    showDialog(
                      context: context,
                      builder: (_) => Dialog(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: SingleChildScrollView(
                            child: _PrescriptionPadPreview(
                              payload: payload,
                              patient: patientProfile,
                              doctor: doctorProfile,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                  icon: const Icon(Icons.visibility),
                  label: const Text('Preview'),
                ),
                const Spacer(),
                FilledButton.icon(
                  onPressed: _textValid ? _saveTextPrescription : null,
                  icon: const Icon(Icons.save),
                  label: Text(editing ? 'Update' : 'Save'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _medicinesEditor() {
    return Column(
      children: [
        Row(
          children: [
            Text('Medicines', style: Theme.of(context).textTheme.titleSmall),
            const Spacer(),
            FilledButton.tonalIcon(
              onPressed: () => setState(() => meds.add(_MedRow())),
              icon: const Icon(Icons.add),
              label: const Text('Add medicine'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ...List.generate(meds.length, (i) => _medicineRow(i)),
      ],
    );
  }

  Widget _medicineRow(int i) {
    final m = meds[i];
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            Row(children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(labelText: 'Name'),
                  controller: TextEditingController(text: m.name),
                  onChanged: (v) => m.name = v,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(labelText: 'Dose (e.g., 500 mg)'),
                  controller: TextEditingController(text: m.dose),
                  onChanged: (v) => m.dose = v,
                ),
              ),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(labelText: 'Form (tab/cap/syrup)'),
                  controller: TextEditingController(text: m.form),
                  onChanged: (v) => m.form = v,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(labelText: 'Frequency (e.g., 1-0-1)'),
                  controller: TextEditingController(text: m.frequency),
                  onChanged: (v) => m.frequency = v,
                ),
              ),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(labelText: 'Duration (e.g., 5 days)'),
                  controller: TextEditingController(text: m.duration),
                  onChanged: (v) => m.duration = v,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(labelText: 'Notes'),
                  controller: TextEditingController(text: m.notes),
                  onChanged: (v) => m.notes = v,
                ),
              ),
              IconButton(
                onPressed: meds.length == 1 ? null : () => setState(() => meds.removeAt(i)),
                icon: const Icon(Icons.remove_circle_outline),
                tooltip: 'Remove',
              ),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _followUpRow() {
    final text = followUp == null ? 'No date' : DateFormat.yMMMd().format(followUp!);
    return Row(
      children: [
        Text('Follow-up: $text'),
        const Spacer(),
        FilledButton.tonal(
          onPressed: () async {
            final now = DateTime.now();
            final d = await showDatePicker(
              context: context,
              firstDate: now.subtract(const Duration(days: 1)),
              lastDate: now.add(const Duration(days: 730)),
              initialDate: followUp ?? now,
            );
            if (d != null) setState(() => followUp = d);
          },
          child: const Text('Pick date'),
        ),
        const SizedBox(width: 8),
        IconButton(
          tooltip: 'Clear',
          onPressed: () => setState(() => followUp = null),
          icon: const Icon(Icons.close),
        ),
      ],
    );
  }

 //// === START REPLACE: _prescriptionTile ===
Widget _prescriptionTile(Map<String, dynamic> p) {
  final type = _rxType(p); // robust: 'text' | 'file' (or inferred)
  final isText = type == 'text';
  final created = (p['created_at'] ?? p['created'] ?? '').toString();
  final id = (p['id'] ?? p['prescription_id']) is num
      ? ((p['id'] ?? p['prescription_id']) as num).toInt()
      : int.tryParse((p['id'] ?? p['prescription_id'] ?? '').toString());

  // Robust URL extraction for files (covers file_url, pdf_url, url, path, data.*)
  final fileUrl = _rxFileUrl(p);

  // For text-preview buttons (PDF/JPG) look at both top-level and nested data.*
  String? _maybe(String? s) => (s == null || s.trim().isEmpty) ? null : _absUrlFromString(s.trim());
  final Map<String, dynamic>? data =
      (p['data'] is Map) ? (p['data'] as Map).cast<String, dynamic>() : null;
  final pdfUrl = _maybe(p['pdf_url']?.toString()) ?? _maybe(data?['pdf_url']?.toString());
  final jpgUrl = _maybe(p['jpg_url']?.toString()) ?? _maybe(data?['jpg_url']?.toString());

  // Titles
  final title = isText
      ? (p['title'] ??
              p['content'] ??
              (data?['diagnosis']?.toString().isNotEmpty == true
                  ? 'Text prescription • ${data?['diagnosis']}'
                  : 'Text prescription'))
          .toString()
      : (p['title'] ?? 'File prescription').toString();

  return Card(
    child: ListTile(
      leading: Icon(isText ? Icons.description_outlined : Icons.attachment),
      title: Text(title, maxLines: 2, overflow: TextOverflow.ellipsis),
      subtitle: Text(created),
      onTap: () async {
        if (isText) {
          // Pad-style preview
          final payload = data ??
              <String, dynamic>{'content': (p['content'] ?? '').toString()};
          showDialog(
            context: context,
            builder: (_) => Dialog(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SingleChildScrollView(
                  child: _PrescriptionPadPreview(
                    payload: payload,
                    patient: patientProfile,
                    doctor: doctorProfile,
                    pdfUrl: pdfUrl,
                    jpgUrl: jpgUrl,
                  ),
                ),
              ),
            ),
          );
        } else {
          // Open file; prefer direct file URL, else pdf/jpg fallbacks
          final u = fileUrl ?? pdfUrl ?? jpgUrl;
          if (u == null || u.isEmpty) {
            if (!mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('No file URL available')),
            );
            return;
          }
          final lower = u.toLowerCase();
          final isImg = lower.endsWith('.png') ||
              lower.endsWith('.jpg') ||
              lower.endsWith('.jpeg') ||
              lower.endsWith('.webp') ||
              lower.endsWith('.gif');
          if (isImg) {
            showDialog(
              context: context,
              builder: (_) => Dialog(
                clipBehavior: Clip.antiAlias,
                child: InteractiveViewer(
                  minScale: 0.5,
                  maxScale: 4,
                  child: Image.network(u, fit: BoxFit.contain),
                ),
              ),
            );
          } else {
            await launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication);
          }
        }
      },
      trailing: Wrap(spacing: 6, children: [
        if (isText && id != null && canEdit)
          IconButton(
            tooltip: 'Edit',
            icon: const Icon(Icons.edit),
            onPressed: () => _startEdit(p),
          ),
        if (id != null && canEdit)
          IconButton(
            tooltip: 'Delete',
            icon: const Icon(Icons.delete_outline),
            onPressed: () =>
                isText ? _deleteTextPrescription(id) : _deleteFilePrescription(id),
          ),
      ]),
    ),
  );
}
//// === END REPLACE: _prescriptionTile ===

}

// --- helpers for AppointmentDetail

class _MedRow {
  _MedRow({
    this.name = '',
    this.dose = '',
    this.form = '',
    this.frequency = '',
    this.duration = '',
    this.notes = '',
  });
  String name, dose, form, frequency, duration, notes;
}

class _PrescriptionPadPreview extends StatelessWidget {
  final Map<String, dynamic> payload;
  final Map<String, dynamic>? patient;
  final Map<String, dynamic>? doctor;
  final String? pdfUrl;
  final String? jpgUrl;

  const _PrescriptionPadPreview({
    super.key,
    required this.payload,
    this.patient,
    this.doctor,
    this.pdfUrl,
    this.jpgUrl,
  });

  @override
  Widget build(BuildContext context) {
    final meds = (payload['medicines'] as List?)?.cast<Map>() ?? const [];
    final p = patient ?? const {};
    final d = doctor ?? const {};
    final now = DateFormat.yMMMd().format(DateTime.now());

    return Container(
      width: 720,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Theme.of(context).dividerColor),
        color: Theme.of(context).colorScheme.surface,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // header
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const CircleAvatar(radius: 26, child: Icon(Icons.local_hospital)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(d['name']?.toString() ?? 'Dr.',
                        style: Theme.of(context).textTheme.titleMedium),
                    Text(d['specialty']?.toString() ?? '',
                        style: Theme.of(context).textTheme.bodySmall),
                    Text(d['category']?.toString() ?? '',
                        style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('Date: $now'),
                  if (d['phone'] != null) Text('Phone: ${d['phone']}'),
                ],
              )
            ],
          ),
          const Divider(height: 24),
          // patient line
          Text(
            'Patient: ${p['name'] ?? '-'}   •   Age: ${p['profile']?['age'] ?? p['age'] ?? '-'}   •   Sex: ${p['profile']?['gender'] ?? p['gender'] ?? '-'}',
          ),
          const SizedBox(height: 8),

          if ((payload['diagnosis'] ?? '').toString().isNotEmpty) ...[
            Text('Diagnosis', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 4),
            Text(payload['diagnosis'].toString()),
            const SizedBox(height: 12),
          ],

          if (meds.isNotEmpty) ...[
            Text('Rx', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 4),
            ...meds.map((m) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(child: Text(m['name']?.toString() ?? '')),
                      Expanded(child: Text('Dose: ${m['dose'] ?? ''}')),
                      Expanded(child: Text('Form: ${m['form'] ?? ''}')),
                      Expanded(child: Text('Freq: ${m['frequency'] ?? ''}')),
                    ],
                  ),
                )),
            const SizedBox(height: 12),
          ],

          if ((payload['advice'] ?? '').toString().isNotEmpty) ...[
            Text('Advice / Instructions', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 4),
            Text(payload['advice'].toString()),
            const SizedBox(height: 12),
          ],

          Text('Follow-up: ${(payload['follow_up'] ?? '').toString().isEmpty ? 'No date' : payload['follow_up']}'),
          const SizedBox(height: 16),

          Row(
            children: [
              if (jpgUrl != null)
                OutlinedButton.icon(
                  onPressed: () => launchUrl(Uri.parse(jpgUrl!), mode: LaunchMode.externalApplication),
                  icon: const Icon(Icons.image),
                  label: const Text('Open JPG'),
                ),
              const SizedBox(width: 8),
              if (pdfUrl != null)
                OutlinedButton.icon(
                  onPressed: () => launchUrl(Uri.parse(pdfUrl!), mode: LaunchMode.externalApplication),
                  icon: const Icon(Icons.picture_as_pdf),
                  label: const Text('Open PDF'),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

//// === END REPLACE: AppointmentDetail ===

//// === START ADD: Chat & Video stubs ===

/// Minimal video-call page that launches the given URL.
/// Works on mobile and Flutter web using url_launcher.
class VideoCallPage extends StatelessWidget {
  const VideoCallPage({super.key, required this.roomUrl});
  final String roomUrl;

  @override
  Widget build(BuildContext context) {
    Future<void> _open() async {
      final uri = Uri.tryParse(roomUrl);
      if (uri != null) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Invalid room URL')));
      }
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Video call')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.videocam, size: 64),
            const SizedBox(height: 16),
            Text(
              roomUrl,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _open,
              icon: const Icon(Icons.open_in_new),
              label: const Text('Open call in browser'),
            ),
          ],
        ),
      ),
    );
  }
}

/// Minimal chat page placeholder so your build compiles.
/// Replace this with your actual chat screen when ready.
class ChatPage extends StatefulWidget {
  const ChatPage({super.key, required this.patientId, required this.apptId});
  final int patientId;
  final int apptId;

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final _text = TextEditingController();
  final List<String> _msgs = [];

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            Text('Chat • patient #${widget.patientId} • appt #${widget.apptId}'),
      ),
      body: Column(
        children: [
          Expanded(
            child: _msgs.isEmpty
                ? const Center(child: Text('No messages yet'))
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _msgs.length,
                    itemBuilder: (_, i) => Align(
                      alignment: i.isEven
                          ? Alignment.centerLeft
                          : Alignment.centerRight,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Theme.of(context)
                              .colorScheme
                              .primaryContainer
                              .withOpacity(i.isEven ? .5 : .9),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(_msgs[i]),
                      ),
                    ),
                  ),
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _text,
                    decoration: const InputDecoration(
                      hintText: 'Type a message…',
                      border: OutlineInputBorder(),
                    ),
                    onSubmitted: (_) => _send(),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton.icon(
                  onPressed: _send,
                  icon: const Icon(Icons.send),
                  label: const Text('Send'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _send() {
    final t = _text.text.trim();
    if (t.isEmpty) return;
    setState(() {
      _msgs.add(t);
    });
    _text.clear();
  }
}

//// === END ADD: Chat & Video stubs ===

// ====== patients tab

class PatientsTab extends StatefulWidget {
  const PatientsTab({super.key});
  @override
  State<PatientsTab> createState() => _PatientsTabState();
}

class _PatientsTabState extends State<PatientsTab> {
  final TextEditingController _q = TextEditingController();
  List<Map<String, dynamic>> items = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final r = await Api.get('/doctor/patients',
          query: _q.text.trim().isEmpty ? null : {'q': _q.text.trim()});
      final list =
          (r as List).map((e) => (e as Map).cast<String, dynamic>()).toList();
      if (!mounted) return;
      setState(() {
        items = list;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Load failed: $e')));
    }
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _q,
                decoration: const InputDecoration(
                  hintText: 'Search by name / phone / email',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(),
                ),
                onSubmitted: (_) => _load(),
              ),
            ),
            const SizedBox(width: 8),
            FilledButton.tonal(onPressed: _load, child: const Text('Search')),
          ],
        ),
      ),
      Expanded(
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : ListView.separated(
                itemCount: items.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (ctx, i) {
                  final p = items[i];
                  final pid = (p['patient_id'] ?? p['id']) as int?;
                  return ListTile(
                    title: Text(p['name'] ?? (pid != null ? 'Patient #$pid' : 'Patient')),
                    subtitle: Text('${p['email'] ?? ''}  ${p['phone'] ?? ''}'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: pid == null
                        ? null
                        : () => Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => PatientProfilePage(patientId: pid),
                              ),
                            ),
                  );
                }),
      ),
    ]);
  }
}

class PatientProfilePage extends StatefulWidget {
  final int patientId;
  const PatientProfilePage({super.key, required this.patientId});
  @override
  State<PatientProfilePage> createState() => _PatientProfilePageState();
}

class _PatientProfilePageState extends State<PatientProfilePage> {
  Map<String, dynamic>? data;
  List<Map<String, dynamic>> reports = [];
  List<Map<String, dynamic>> prescriptions = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  String? _absUrl(Map<String, dynamic> m) => _absUrlFromMap(m);

  Future<void> _openImage(String url) async {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        clipBehavior: Clip.antiAlias,
        child: InteractiveViewer(
          minScale: 0.5,
          maxScale: 4,
          child: Image.network(url, fit: BoxFit.contain),
        ),
      ),
    );
  }

  Future<void> _openFile(Map<String, dynamic> m) async {
    final url = _absUrl(m);
    if (url == null) return;
    if (_looksLikeImage(url)) {
      await _openImage(url);
      return;
    }
    final uri = Uri.parse(url);
    if (!await canLaunchUrl(uri)) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _load() async {
    try {
      final p = await Api.get('/patients/${widget.patientId}');
      final r = await Api.get('/patients/${widget.patientId}/reports');
      setState(() {
        data = (p as Map).cast<String, dynamic>();
        reports = (r as List).map((e) => (e as Map).cast<String, dynamic>()).toList();
      });
    } catch (_) {}
    try {
      final pr = await Api.get('/patients/${widget.patientId}/prescriptions');
      prescriptions =
          (pr as List).map((e) => (e as Map).cast<String, dynamic>()).toList();
      setState(() {});
    } catch (_) {}
  }

  Widget _grid(List<Map<String, dynamic>> items) {
    if (items.isEmpty) return const Text('No files');
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: items.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3, crossAxisSpacing: 6, mainAxisSpacing: 6),
      itemBuilder: (_, i) {
        final it = items[i];
        final url = _absUrl(it);
        return InkWell(
          onTap: url == null ? null : () => _openImage(url),
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(color: Theme.of(context).dividerColor),
              borderRadius: BorderRadius.circular(8),
            ),
            child: url == null
                ? const Center(child: Icon(Icons.insert_drive_file))
                : ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(url, fit: BoxFit.cover),
                  ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final d = data;
    if (d == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final profile = (d['profile'] as Map?) ?? d;

    return Scaffold(
      appBar: AppBar(title: Text(d['name'] ?? 'Patient #${widget.patientId}')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Wrap(spacing: 10, runSpacing: 6, children: [
            _Pill('Age: ${profile['age'] ?? '-'}'),
            _Pill('Weight: ${profile['weight'] ?? '-'}'),
            _Pill('Height: ${profile['height'] ?? '-'}'),
            _Pill('Blood: ${profile['blood_group'] ?? '-'}'),
            _Pill('Gender: ${profile['gender'] ?? '-'}'),
          ]),
          const SizedBox(height: 12),
          Text('Description: ${profile['description'] ?? ''}'),
          const SizedBox(height: 6),
          Text('Current medicine: ${profile['current_medicine'] ?? ''}'),
          const SizedBox(height: 6),
          Text('History: ${profile['medical_history'] ?? ''}'),
          const Divider(height: 32),
          Text('Reports', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          _grid(reports),
          const Divider(height: 32),
          Text('Prescriptions', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (prescriptions.isEmpty)
            const Text('No prescriptions yet.')
          else
            ...prescriptions.map((p) => ListTile(
                  leading: const Icon(Icons.medication_liquid),
                  title: Text(p['title']?.toString() ?? 'Prescription'),
                  subtitle: Text(p['created_at']?.toString() ?? ''),
                  onTap: () => _openFile(p),
                )),
        ],
      ),
    );
  }
}

// ====== schedule tab (list first, then create; inline edit for date rules)

class ScheduleTab extends StatefulWidget {
  const ScheduleTab({super.key});
  @override
  State<ScheduleTab> createState() => _ScheduleTabState();
}

enum WeeklySort { byDay, byCreatedNewest, byCreatedOldest }
enum DatedSort { byDateNewest, byDateOldest, byCreatedNewest, byCreatedOldest }

class _ScheduleTabState extends State<ScheduleTab> {
  // creation form state (hidden by default, shown when pressing "Create new")
  bool showCreate = false;

  // weekly creation
  final Set<int> selectedDays = {}; // Mon=0..Sun=6
  int startHour = 9;
  int endHour = 17;

  // date-specific creation (independent hours, max, mode)
  int dateStartHour = 9;
  int dateEndHour = 17;
  int dateMaxPatients = 4;
  String dateMode = 'offline';

  // 'defaults' copied from weekly tab on demand button
  int maxPatientsWeekly = 4;
  String visitModeWeekly = 'offline';

  // date creation
  DateTime currentMonth =
      DateTime(DateTime.now().year, DateTime.now().month, 1);
  final Set<DateTime> selectedDates = {};

  // existing rules
  List<Map<String, dynamic>> weeklyRules = [];
  List<Map<String, dynamic>> datedRules = [];
  bool loading = true;

  // sorting
  WeeklySort weeklySort = WeeklySort.byDay;
  DatedSort datedSort = DatedSort.byDateNewest;

  @override
  void initState() {
    super.initState();
    _loadSchedule();
  }

  String _fmtDate(DateTime d) => DateFormat('yyyy-MM-dd').format(d);

  Future<void> _loadSchedule() async {
    setState(() => loading = true);
    try {
      final r = await Api.get('/doctor/schedule');
      final j = (r as Map).cast<String, dynamic>();

      final weekly = (j['weekly'] ?? j['weekly_rules']) as List? ?? const [];
      final dated = (j['dated'] ?? j['date_rules']) as List? ?? const [];

      setState(() {
        weeklyRules =
            weekly.map((e) => (e as Map).cast<String, dynamic>()).toList();
        datedRules =
            dated.map((e) => (e as Map).cast<String, dynamic>()).toList();
        loading = false;
      });
    } on DioException {
      // Fallback to the legacy availability endpoint so the UI still works
      try {
        final alt = await Api.get('/doctor/availability');
        final list = (alt as List)
            .map((e) => (e as Map).cast<String, dynamic>())
            .toList();

        final weekly = list
            .map((a) => {
                  'id': a['id'],
                  'dow': a['day_of_week'],
                  'start': '${a['start_hour'].toString().padLeft(2, '0')}:00',
                  'end': '${a['end_hour'].toString().padLeft(2, '0')}:00',
                  'start_hour': a['start_hour'],
                  'end_hour': a['end_hour'],
                  'active': a['active'] == true,
                  'mode': a['mode'] ?? 'offline',
                  'max_patients': a['max_patients'] ?? 4,
                  'created_at': null,
                })
            .toList();

        setState(() {
          weeklyRules = weekly;
          datedRules = const [];
          loading = false;
        });
      } catch (e2) {
        setState(() => loading = false);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Load schedule failed (fallback): $e2')),
        );
      }
    }
  }

  // helpers
  int _dowSun0ToMon0(int dowSun0) => (dowSun0 + 6) % 7;

  List<Map<String, dynamic>> get _weeklySorted {
    final list = [...weeklyRules];
    switch (weeklySort) {
      case WeeklySort.byDay:
        list.sort((a, b) {
          final am = _dowSun0ToMon0((a['dow'] as num).toInt());
          final bm = _dowSun0ToMon0((b['dow'] as num).toInt());
          final c = am.compareTo(bm);
          if (c != 0) return c;
          final ash = (a['start_hour'] ?? 0) as int;
          final bsh = (b['start_hour'] ?? 0) as int;
          return ash.compareTo(bsh);
        });
        break;
      case WeeklySort.byCreatedNewest:
        list.sort((a, b) =>
            (b['created_at'] ?? '').toString().compareTo((a['created_at'] ?? '').toString()));
        break;
      case WeeklySort.byCreatedOldest:
        list.sort((a, b) =>
            (a['created_at'] ?? '').toString().compareTo((b['created_at'] ?? '').toString()));
        break;
    }
    return list;
  }

  List<Map<String, dynamic>> get _datedSorted {
    final list = [...datedRules];
    int cmpDate(a, b) => (b['date'] ?? '').toString().compareTo((a['date'] ?? '').toString());
    int cmpDateAsc(a, b) => (a['date'] ?? '').toString().compareTo((b['date'] ?? '').toString());
    int cmpCreated(a, b) => (b['created_at'] ?? '').toString().compareTo((a['created_at'] ?? '').toString());
    int cmpCreatedAsc(a, b) => (a['created_at'] ?? '').toString().compareTo((b['created_at'] ?? '').toString());
    switch (datedSort) {
      case DatedSort.byDateNewest:
        list.sort(cmpDate);
        break;
      case DatedSort.byDateOldest:
        list.sort(cmpDateAsc);
        break;
      case DatedSort.byCreatedNewest:
        list.sort(cmpCreated);
        break;
      case DatedSort.byCreatedOldest:
        list.sort(cmpCreatedAsc);
        break;
    }
    return list;
  }

  Future<void> _saveWeekly() async {
    try {
      final form = FormData.fromMap({
        'selected_days': selectedDays.toList(), // Mon=0..Sun=6
        'start_hour': startHour,
        'end_hour': endHour,
        'max_patients': maxPatientsWeekly,
        'visit_mode': visitModeWeekly, // endpoint expects visit_mode
      });
      await Api.post('/doctor/schedule/weekly_set', data: form, multipart: true);

      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Weekly schedule saved')));
      setState(() => showCreate = false);
      _loadSchedule();
    } on DioException catch (e) {
      _showHttp(e);
    }
  }

  Future<void> _saveDates() async {
    try {
      final dates = selectedDates.map(_fmtDate).toList();
      if (dates.isEmpty) return;

      // Build multipart with repeated "dates" + send **mode** (API expects 'mode')
      final form = FormData();
      for (final d in dates) {
        form.fields.add(MapEntry('dates', d));
      }
      form.fields.addAll([
        MapEntry('start_hour', dateStartHour.toString()),
        MapEntry('end_hour', dateEndHour.toString()),
        MapEntry('max_patients', dateMaxPatients.toString()),
        MapEntry('mode', dateMode), // <-- important
        const MapEntry('active', 'true'),
      ]);

      await Api.post('/doctor/schedule/date_rule', data: form, multipart: true);

      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Daily plan saved')));
      selectedDates.clear();
      setState(() => showCreate = false);
      _loadSchedule();
    } on DioException catch (e) {
      _showHttp(e);
    }
  }

  Future<void> _editDateRule(Map<String, dynamic> r) async {
    final startText = TextEditingController(
        text: (r['start'] ?? '${r['start_hour']}:00').toString());
    final endText = TextEditingController(
        text: (r['end'] ?? '${r['end_hour']}:00').toString());
    final maxText =
        TextEditingController(text: (r['max_patients'] ?? '4').toString());
    String mode = (r['visit_mode'] ?? r['mode'] ?? 'offline').toString();

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
            left: 16,
            right: 16,
            top: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Edit ${r['date']}',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            TextField(
              controller: startText,
              decoration: const InputDecoration(labelText: 'Start (HH:mm)'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: endText,
              decoration: const InputDecoration(labelText: 'End (HH:mm)'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: maxText,
              decoration: const InputDecoration(labelText: 'Max patients'),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: mode,
              items: const [
                DropdownMenuItem(value: 'offline', child: Text('Offline')),
                DropdownMenuItem(value: 'online', child: Text('Online')),
              ],
              onChanged: (v) => mode = v ?? 'offline',
              decoration: const InputDecoration(labelText: 'Mode'),
            ),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton.icon(
                onPressed: () async {
                  try {
                    await Api.patch('/doctor/schedule/date_rule/${r['id']}',
                        data: {
                          'start': startText.text,
                          'end': endText.text,
                          'max_patients': int.tryParse(maxText.text) ??
                              r['max_patients'],
                          'mode': mode,
                        });
                    if (!mounted) return;
                    Navigator.pop(context);
                    _loadSchedule();
                    ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Updated')));
                  } on DioException catch (e) {
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text(
                            'HTTP ${e.response?.statusCode}: ${e.response?.data}')));
                  }
                },
                icon: const Icon(Icons.save),
                label: const Text('Save'),
              ),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  void _toggleRule(bool active, int id, String kind) async {
    try {
      await Api.post('/doctor/schedule/toggle',
          data: FormData.fromMap(
              {'item_id': id, 'kind': kind, 'active': active}),
          multipart: true);
    } on DioException catch (e) {
      _showHttp(e);
    } finally {
      _loadSchedule();
    }
  }

  Future<void> _deleteRule(int id, String kind) async {
    try {
      if (kind == 'weekly') {
        await Api.delete('/doctor/schedule/weekly/$id');
      } else {
        await Api.delete('/doctor/schedule/date_rule/$id');
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Deleted')));
      _loadSchedule();
    } on DioException catch (e) {
      _showHttp(e);
    }
  }

  void _showHttp(DioException e) {
    final code = e.response?.statusCode;
    final body = e.response?.data;
    final msg = e.message ?? e.error?.toString() ?? 'Network error';
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content:
              Text(code == null ? 'Network error: $msg' : 'HTTP $code: $body')),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }

    final weeklyList = _weeklySorted;
    final datedList = _datedSorted;

    String _fmtCreated(Map<String, dynamic> r) {
      final s = (r['created_at'] ?? r['created'] ?? '').toString();
      if (s.isEmpty) return '';
      try {
        final d = DateTime.parse(s);
        return DateFormat.yMMMd().add_Hm().format(d);
      } catch (_) {
        return s;
      }
    }

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        // header row + sorters
        Row(
          children: [
            Text('Schedules', style: Theme.of(context).textTheme.titleLarge),
            const Spacer(),
            DropdownButton<WeeklySort>(
              value: weeklySort,
              onChanged: (v) => setState(() => weeklySort = v ?? weeklySort),
              items: const [
                DropdownMenuItem(
                    value: WeeklySort.byDay, child: Text('Weekly: by day')),
                DropdownMenuItem(
                    value: WeeklySort.byCreatedNewest,
                    child: Text('Weekly: created ↓')),
                DropdownMenuItem(
                    value: WeeklySort.byCreatedOldest,
                    child: Text('Weekly: created ↑')),
              ],
            ),
            const SizedBox(width: 8),
            DropdownButton<DatedSort>(
              value: datedSort,
              onChanged: (v) => setState(() => datedSort = v ?? datedSort),
              items: const [
                DropdownMenuItem(
                    value: DatedSort.byDateNewest, child: Text('Dates: date ↓')),
                DropdownMenuItem(
                    value: DatedSort.byDateOldest, child: Text('Dates: date ↑')),
                DropdownMenuItem(
                    value: DatedSort.byCreatedNewest,
                    child: Text('Dates: created ↓')),
                DropdownMenuItem(
                    value: DatedSort.byCreatedOldest,
                    child: Text('Dates: created ↑')),
              ],
            ),
            const SizedBox(width: 12),
            FilledButton.icon(
              onPressed: () => setState(() => showCreate = !showCreate),
              icon: Icon(showCreate ? Icons.close : Icons.add),
              label: Text(showCreate ? 'Close' : 'Create new'),
            ),
          ],
        ),
        const SizedBox(height: 12),

        if (!showCreate) ...[
          Text('Weekly rules', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (weeklyList.isEmpty)
            Text(
              'No weekly rules yet. Tap "Create new" to add.',
              style: Theme.of(context).textTheme.bodySmall,
            )
          else
            ...weeklyList.map((w) {
              final id = (w['id'] as num).toInt();
              final active = w['active'] == true;
              final start = w['start'] ?? '${w['start_hour']}:00';
              final end = w['end'] ?? '${w['end_hour']}:00';
              final mode =
                  (w['visit_mode'] ?? w['mode'] ?? 'offline').toString();
              final dowSun0 = (w['dow'] as num).toInt();
              final dowMon0 = _dowSun0ToMon0(dowSun0);
              const dows = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
              final created = _fmtCreated(w);

              final tile = SwitchListTile(
                title: Text(
                    '${dows[dowMon0]}  $start - $end  • $mode (max ${w['max_patients'] ?? '-'})'),
                value: active,
                onChanged: (v) => _toggleRule(v, id, 'weekly'),
                secondary: IconButton(
                  tooltip: 'Delete',
                  icon: const Icon(Icons.delete_forever),
                  onPressed: () => _deleteRule(id, 'weekly'),
                ),
              );

              // Only tooltip (no inline created-at text)
              return created.isEmpty
                  ? tile
                  : Tooltip(message: 'Created $created', child: tile);
            }),
          const SizedBox(height: 16),
          Text('Date rules', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (datedList.isEmpty)
            Text(
              'No date rules yet. Tap "Create new" to add.',
              style: Theme.of(context).textTheme.bodySmall,
            )
          else
            ...datedList.map((w) {
              final id = (w['id'] as num).toInt();
              final active = w['active'] == true;
              final start = w['start'] ?? '${w['start_hour']}:00';
              final end = w['end'] ?? '${w['end_hour']}:00';
              final mode =
                  (w['visit_mode'] ?? w['mode'] ?? 'offline').toString();
              final created = _fmtCreated(w);

              final tile = Card(
                child: ListTile(
                  title: Text(
                      '${w['date']}  $start - $end  • $mode (max ${w['max_patients'] ?? '-'})'),
                  trailing: Wrap(spacing: 6, children: [
                    IconButton(
                      tooltip: 'Edit hours',
                      onPressed: () => _editDateRule(w),
                      icon: const Icon(Icons.edit_calendar),
                    ),
                    Switch(
                      value: active,
                      onChanged: (v) => _toggleRule(v, id, 'dated'),
                    ),
                    IconButton(
                      tooltip: 'Delete',
                      onPressed: () => _deleteRule(id, 'dated'),
                      icon: const Icon(Icons.delete_forever),
                    ),
                  ]),
                ),
              );

              return created.isEmpty
                  ? tile
                  : Tooltip(message: 'Created $created', child: tile);
            }),
        ],

        if (showCreate) ...[
          const Divider(height: 24),
          Text('Create Weekly / Date Schedules',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),

          // weekly picker
          Text('Weekly (choose days & hours)',
              style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: List.generate(7, (i) {
              const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
              final on = selectedDays.contains(i);
              return FilterChip(
                label: Text(labels[i]),
                selected: on,
                onSelected: (v) => setState(
                    () => v ? selectedDays.add(i) : selectedDays.remove(i)),
              );
            }),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: DropdownButtonFormField<int>(
                value: startHour,
                items: List.generate(
                    24,
                    (i) => DropdownMenuItem(
                        value: i,
                        child: Text('${i.toString().padLeft(2, '0')}:00'))),
                onChanged: (v) => setState(() => startHour = v ?? 9),
                decoration: const InputDecoration(labelText: 'Start hour'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: DropdownButtonFormField<int>(
                value: endHour,
                items: List.generate(
                    24,
                    (i) => DropdownMenuItem(
                        value: i,
                        child: Text('${i.toString().padLeft(2, '0')}:00'))),
                onChanged: (v) => setState(() => endHour = v ?? 17),
                decoration: const InputDecoration(labelText: 'End hour'),
              ),
            ),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: TextFormField(
                initialValue: maxPatientsWeekly.toString(),
                decoration: const InputDecoration(labelText: 'Max patients'),
                onChanged: (v) => maxPatientsWeekly = int.tryParse(v) ?? 4,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: DropdownButtonFormField<String>(
                value: visitModeWeekly,
                items: const [
                  DropdownMenuItem(value: 'offline', child: Text('Offline')),
                  DropdownMenuItem(value: 'online', child: Text('Online')),
                ],
                onChanged: (v) => setState(() => visitModeWeekly = v ?? 'offline'),
                decoration: const InputDecoration(labelText: 'Mode'),
              ),
            ),
          ]),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: FilledButton.icon(
              onPressed: selectedDays.isEmpty ? null : _saveWeekly,
              icon: const Icon(Icons.save),
              label: const Text('Save weekly'),
            ),
          ),
          const Divider(height: 24),

          // date picker + per-date options
          Text('Specific Dates (tap calendar cells)',
              style: Theme.of(context).textTheme.titleSmall),
          const SizedBox(height: 6),

          Row(children: [
            Expanded(
              child: DropdownButtonFormField<int>(
                value: dateStartHour,
                items: List.generate(
                    24,
                    (i) => DropdownMenuItem(
                        value: i,
                        child: Text('${i.toString().padLeft(2, '0')}:00'))),
                onChanged: (v) => setState(() => dateStartHour = v ?? 9),
                decoration:
                    const InputDecoration(labelText: 'Start hour (dates)'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: DropdownButtonFormField<int>(
                value: dateEndHour,
                items: List.generate(
                    24,
                    (i) => DropdownMenuItem(
                        value: i,
                        child: Text('${i.toString().padLeft(2, '0')}:00'))),
                onChanged: (v) => setState(() => dateEndHour = v ?? 17),
                decoration:
                    const InputDecoration(labelText: 'End hour (dates)'),
              ),
            ),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: TextFormField(
                initialValue: dateMaxPatients.toString(),
                decoration: const InputDecoration(labelText: 'Max patients (dates)'),
                onChanged: (v) => dateMaxPatients = int.tryParse(v) ?? 4,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: DropdownButtonFormField<String>(
                value: dateMode,
                items: const [
                  DropdownMenuItem(value: 'offline', child: Text('Offline')),
                  DropdownMenuItem(value: 'online', child: Text('Online')),
                ],
                onChanged: (v) => setState(() => dateMode = v ?? 'offline'),
                decoration: const InputDecoration(labelText: 'Mode (dates)'),
              ),
            ),
          ]),
          const SizedBox(height: 8),

          _MonthGrid(
            month: currentMonth,
            selected: selectedDates,
            onChanged: (set) => setState(() {
              selectedDates
                ..clear()
                ..addAll(set);
            }),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: FilledButton.icon(
              onPressed: selectedDates.isEmpty ? null : _saveDates,
              icon: const Icon(Icons.save),
              label: const Text('Save selected dates'),
            ),
          ),
          const SizedBox(height: 8),
        ],
      ],
    );
  }
}

class _MonthGrid extends StatelessWidget {
  final DateTime month;
  final Set<DateTime> selected;
  final ValueChanged<Set<DateTime>> onChanged;

  const _MonthGrid(
      {required this.month, required this.selected, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final first = DateTime(month.year, month.month, 1);
    final start =
        first.subtract(Duration(days: (first.weekday + 6) % 7)); // Monday start
    final days =
        List<DateTime>.generate(42, (i) => DateTime(start.year, start.month, start.day + i));

    bool isSameDay(DateTime a, DateTime b) =>
        a.year == b.year && a.month == b.month && a.day == b.day;

    Set<DateTime> sel = {...selected};

    return GridView.builder(
      shrinkWrap: true,
      itemCount: days.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 7, mainAxisExtent: 56, crossAxisSpacing: 4, mainAxisSpacing: 4),
      itemBuilder: (_, i) {
        final d = days[i];
        final inMonth = d.month == month.month;
        final on = sel.any((x) => isSameDay(x, d));
        return InkWell(
          onTap: () {
            if (on) {
              sel.removeWhere((x) => isSameDay(x, d));
            } else {
              sel.add(DateTime(d.year, d.month, d.day));
            }
            onChanged(sel);
          },
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              color: on ? Theme.of(context).colorScheme.primaryContainer : null,
              border: Border.all(color: Theme.of(context).dividerColor),
            ),
            child: Center(
              child: Text(
                '${d.day}',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: inMonth ? null : Theme.of(context).disabledColor,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

// ====== profile tab (doctor) + change password + photo/docs upload

class ProfileTab extends StatefulWidget {
  const ProfileTab({super.key});
  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  Doctor? me;
  bool edit = false;

  final _name = TextEditingController();
  final _specialty = TextEditingController();
  final _category = TextEditingController(text: 'General');
  final _keywords = TextEditingController();
  final _bio = TextEditingController();
  final _background = TextEditingController();

  final _oldPass = TextEditingController();
  final _newPass = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await Api.get('/doctor/me'); // preferred
      final j = (r as Map).cast<String, dynamic>();
      final d = Doctor.fromJson(j);
      if (!mounted) return;
      setState(() {
        me = d;
        _name.text = d.name;
        _specialty.text = d.specialty;
        _category.text = d.category;
        _keywords.text = d.keywords;
        _bio.text = d.bio;
        _background.text = d.background;
      });
    } catch (_) {
      try {
        final r = await Api.get('/whoami');
        final j = (r as Map).cast<String, dynamic>();
        if (!mounted) return;
        setState(() {
          me = Doctor(
            id: j['id'] as int,
            name: j['name']?.toString() ?? '',
            email: j['email']?.toString(),
            specialty: '',
            category: 'General',
            keywords: '',
            bio: '',
            background: '',
            rating: 0,
            photoPath: j['photo_path']?.toString(),
          );
          _name.text = me!.name;
        });
      } catch (_) {}
    }
  }

  Future<void> _saveProfile() async {
    try {
      await Api.patch('/doctor/profile', data: {
        'name': _name.text,
        'specialty': _specialty.text,
        'category': _category.text,
        'keywords': _keywords.text,
        'bio': _bio.text,
        'background': _background.text,
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Profile updated')));
      setState(() => edit = false);
      _load();
    } on DioException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('HTTP ${e.response?.statusCode}: ${e.response?.data}')));
    }
  }

  Future<void> _uploadPhoto() async {
    try {
      final mf = await _pickMultipartFile(
        type: null,
        allowedExtensions: ['jpg', 'jpeg', 'png', 'webp', 'heic'],
      );
      if (mf == null) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No file selected')),
        );
        return;
      }

      // Try doctor endpoint; fallback to /me/photo
      try {
        await Api.post('/doctor/profile/photo',
            data: FormData.fromMap({'file': mf}), multipart: true);
      } on DioException catch (e) {
        final code = e.response?.statusCode ?? 0;
        if (code == 404 || code == 405) {
          await Api.post('/me/photo',
              data: FormData.fromMap({'file': mf}), multipart: true);
        } else {
          rethrow;
        }
      }

      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Photo uploaded')));
      await _load();
    } on DioException catch (e) {
      if (!mounted) return;
      final code = e.response?.statusCode;
      final body = e.response?.data;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text(
                code == null ? 'Network error' : 'HTTP $code: $body')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Upload failed: $e')));
    }
  }

  Future<void> _uploadDocuments() async {
    try {
      final mf = await _pickMultipartFile(
        type: null,
        allowedExtensions: ['pdf', 'doc', 'docx', 'png', 'jpg', 'jpeg'],
      );
      if (mf == null) return;
      await Api.post('/doctor/profile/document',
          data: FormData.fromMap({'file': mf}), multipart: true);
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Document uploaded')));
    } on DioException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('HTTP ${e.response?.statusCode}: ${e.response?.data}')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = me;
    if (d == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        ListTile(
          leading: CircleAvatar(
            radius: 26,
            child: d.photoPath == null || d.photoPath!.isEmpty
                ? const Icon(Icons.person)
                : ClipOval(
                    child: Image.network(
                      d.photoPath!.startsWith('http')
                          ? d.photoPath!
                          : '${Api.baseUrl}${d.photoPath}',
                      width: 52,
                      height: 52,
                      fit: BoxFit.cover,
                    ),
                  ),
          ),
          title: Text(d.name),
          subtitle: Text(d.email ?? ''),
          trailing: Wrap(spacing: 8, children: [
            OutlinedButton.icon(
              onPressed: _uploadPhoto,
              icon: const Icon(Icons.photo_camera),
              label: const Text('Upload photo'),
            ),
            OutlinedButton.icon(
              onPressed: _uploadDocuments,
              icon: const Icon(Icons.file_upload),
              label: const Text('Upload docs'),
            ),
          ]),
        ),
        const SizedBox(height: 12),
        if (!edit) ...[
          _ProfileRow('Specialty', d.specialty),
          _ProfileRow('Category', d.category),
          _ProfileRow('Keywords', d.keywords),
          _ProfileRow('Bio', d.bio),
          _ProfileRow('Background', d.background),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: FilledButton.tonal(
              onPressed: () => setState(() => edit = true),
              child: const Text('Edit'),
            ),
          ),
        ] else ...[
          TextField(
              controller: _name,
              decoration: const InputDecoration(labelText: 'Name')),
          const SizedBox(height: 8),
          TextField(
              controller: _specialty,
              decoration: const InputDecoration(labelText: 'Specialty')),
          const SizedBox(height: 8),
          TextField(
              controller: _category,
              decoration: const InputDecoration(labelText: 'Category')),
          const SizedBox(height: 8),
          TextField(
              controller: _keywords,
              decoration: const InputDecoration(labelText: 'Keywords')),
          const SizedBox(height: 8),
          TextField(
              controller: _bio,
              decoration: const InputDecoration(labelText: 'Bio')),
          const SizedBox(height: 8),
          TextField(
              controller: _background,
              decoration: const InputDecoration(labelText: 'Background')),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerRight,
            child: FilledButton.icon(
              onPressed: _saveProfile,
              icon: const Icon(Icons.save),
              label: const Text('Save'),
            ),
          ),
        ],
        const Divider(height: 32),
        Text('Change Password',
            style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        TextField(
            controller: _oldPass,
            obscureText: true,
            decoration:
                const InputDecoration(labelText: 'Current password')),
        const SizedBox(height: 8),
        TextField(
            controller: _newPass,
            obscureText: true,
            decoration: const InputDecoration(labelText: 'New password')),
        const SizedBox(height: 8),
        Align(
          alignment: Alignment.centerRight,
          child: FilledButton.icon(
            onPressed: () async {
              try {
                await Api.post('/auth/change_password',
                    data: {'old': _oldPass.text, 'new': _newPass.text});
                if (!mounted) return;
                ScaffoldMessenger.of(context)
                    .showSnackBar(const SnackBar(content: Text('Password changed')));
                _oldPass.clear();
                _newPass.clear();
              } on DioException catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('HTTP ${e.response?.statusCode}: ${e.response?.data}')));
              }
            },
            icon: const Icon(Icons.lock_reset),
            label: const Text('Update password'),
          ),
        ),
      ],
    );
  }
}

class _ProfileRow extends StatelessWidget {
  final String label;
  final String value;
  const _ProfileRow(this.label, this.value);
  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      dense: true,
      title: Text(label, style: Theme.of(context).textTheme.bodySmall),
      subtitle: Text(value.isEmpty ? '—' : value),
    );
  }
}
