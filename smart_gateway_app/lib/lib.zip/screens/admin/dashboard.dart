import 'package:flutter/material.dart';
import '../../models.dart';
import '../../services/api.dart';
import '../../services/auth.dart';
import '../../widgets/snack.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key, required this.me});
  final User me;

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int idx = 0;

  @override
  Widget build(BuildContext context) {
    final tabs = [
      const _AdminDoctorsTab(),
      const _AdminCreateDoctorTab(),
      const _AdminAppointmentsTab(),
      const _AdminSuspiciousTab(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        actions: [
          IconButton(
              onPressed: () async {
                await AuthService.logout();
                if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
              },
              icon: const Icon(Icons.logout))
        ],
      ),
      body: tabs[idx],
      bottomNavigationBar: NavigationBar(
        selectedIndex: idx,
        onDestinationSelected: (v) => setState(() => idx = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.list), label: 'Doctors'),
          NavigationDestination(icon: Icon(Icons.person_add), label: 'Create Doctor'),
          NavigationDestination(icon: Icon(Icons.event), label: 'Appointments'),
          NavigationDestination(icon: Icon(Icons.report), label: 'Suspicious'),
        ],
      ),
    );
  }
}

class _AdminDoctorsTab extends StatefulWidget {
  const _AdminDoctorsTab();

  @override
  State<_AdminDoctorsTab> createState() => _AdminDoctorsTabState();
}

class _AdminDoctorsTabState extends State<_AdminDoctorsTab> {
  List<Doctor> items = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    final res = await Api.get('/doctors');
    items = (res as List).map((e) => Doctor.fromJson(e)).toList();
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        itemCount: items.length,
        itemBuilder: (_, i) {
          final d = items[i];
          return ListTile(
            leading: CircleAvatar(child: Text(d.name.isNotEmpty ? d.name[0] : '?')),
            title: Text('${d.name} — ${d.specialty}'),
            subtitle: Text('Category: ${d.category} | Rating: ${d.rating}'),
          );
        },
      ),
    );
  }
}

class _AdminCreateDoctorTab extends StatefulWidget {
  const _AdminCreateDoctorTab();

  @override
  State<_AdminCreateDoctorTab> createState() => _AdminCreateDoctorTabState();
}

class _AdminCreateDoctorTabState extends State<_AdminCreateDoctorTab> {
  final name = TextEditingController();
  final email = TextEditingController();
  final phone = TextEditingController();
  final pass = TextEditingController();
  final specialty = TextEditingController();
  final category = TextEditingController(text: 'General');
  final keywords = TextEditingController();
  final bio = TextEditingController();
  final background = TextEditingController();
  bool busy = false;

  Future<void> _create() async {
    setState(() => busy = true);
    try {
      await Api.post('/admin/doctors', data: {
        'name': name.text,
        'email': email.text,
        'phone': phone.text.isEmpty ? null : phone.text,
        'password': pass.text,
        'specialty': specialty.text,
        'category': category.text,
        'keywords': keywords.text,
        'bio': bio.text,
        'background': background.text,
      });
      if (mounted) showSnack(context, 'Doctor created!');
    } catch (e) {
      if (mounted) showSnack(context, 'Failed: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final fields = <Widget>[
      _tf(name, 'Name'),
      _tf(email, 'Email'),
      _tf(phone, 'Phone (optional)'),
      _tf(pass, 'Password', obscure: true),
      _tf(specialty, 'Specialty'),
      _tf(category, 'Category'),
      _tf(keywords, 'Keywords'),
      _tf(bio, 'Bio'),
      _tf(background, 'Background'),
      const SizedBox(height: 12),
      FilledButton(onPressed: busy ? null : _create, child: Text(busy ? 'Saving...' : 'Create Doctor')),
    ];
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(children: fields.map((w) => Padding(padding: const EdgeInsets.only(bottom: 10), child: w)).toList()),
    );
  }

  Widget _tf(TextEditingController c, String label, {bool obscure = false}) {
    return TextField(controller: c, obscureText: obscure, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()));
  }
}

class _AdminAppointmentsTab extends StatefulWidget {
  const _AdminAppointmentsTab();

  @override
  State<_AdminAppointmentsTab> createState() => _AdminAppointmentsTabState();
}

class _AdminAppointmentsTabState extends State<_AdminAppointmentsTab> {
  List<dynamic> items = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    final res = await Api.get('/admin/appointments');
    items = res as List;
    setState(() => loading = false);
  }

  Future<void> _approve(int id, bool ok) async {
    await Api.patch('/admin/appointments/$id/approve', data: {'approve': ok});
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        itemCount: items.length,
        itemBuilder: (_, i) {
          final a = items[i];
          return Card(
            child: ListTile(
              title: Text('Appt #${a["id"]} — ${a["status"]} | ${a["payment_status"]}'),
              subtitle: Text('${a["start_time"]} → ${a["end_time"]}'),
              trailing: Wrap(spacing: 8, children: [
                IconButton(onPressed: () => _approve(a["id"], true), icon: const Icon(Icons.check, color: Colors.green)),
                IconButton(onPressed: () => _approve(a["id"], false), icon: const Icon(Icons.close, color: Colors.red)),
              ]),
            ),
          );
        },
      ),
    );
  }
}

class _AdminSuspiciousTab extends StatefulWidget {
  const _AdminSuspiciousTab();

  @override
  State<_AdminSuspiciousTab> createState() => _AdminSuspiciousTabState();
}

class _AdminSuspiciousTabState extends State<_AdminSuspiciousTab> {
  List<User> items = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    final res = await Api.get('/admin/suspicious');
    items = (res as List).map((e) => User.fromJson(e)).toList();
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator());
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.builder(
        itemCount: items.length,
        itemBuilder: (_, i) {
          final u = items[i];
          return ListTile(
            leading: CircleAvatar(child: Text(u.name.isNotEmpty ? u.name[0] : '?')),
            title: Text(u.name),
            subtitle: Text('${u.email ?? u.phone ?? '-'}'),
          );
        },
      ),
    );
  }
}
