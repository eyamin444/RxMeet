// Routes to the correct implementation per platform.
export 'download_stub.dart'
  if (dart.library.html) 'download_web.dart'
  if (dart.library.io) 'download_mobile.dart';
