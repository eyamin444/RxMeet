import 'dart:async';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Api {
  static late Dio _dio;
  static late String _base;

  static Future<void> init({required String baseUrl}) async {
    _base = baseUrl;
    _dio = Dio(
      BaseOptions(
        baseUrl: _base,
        connectTimeout: const Duration(seconds: 8),
        receiveTimeout: const Duration(seconds: 30),
      ),
    );

    // Attach auth header from SharedPreferences on every request
    _dio.interceptors.add(
      InterceptorsWrapper(onRequest: (opt, handler) async {
        final prefs = await SharedPreferences.getInstance();
        final tok = prefs.getString('token');
        if (tok != null && tok.isNotEmpty) {
          opt.headers['Authorization'] = 'Bearer $tok';
        }
        handler.next(opt);
      }),
    );
  }

  static String get baseUrl => _base;

  // ---- Back-compat: some screens call Api.setToken(null) on logout.
  static Future<void> setToken(String? token) async {
    final prefs = await SharedPreferences.getInstance();
    if (token == null || token.isEmpty) {
      await prefs.remove('token');
    } else {
      await prefs.setString('token', token);
    }
  }

  // GET (JSON)
  static Future<dynamic> get(String path, {Map<String, dynamic>? query}) async {
    final res = await _dio.get(path, queryParameters: query);
    return res.data;
  }

  // GET (bytes)
  static Future<Uint8List> getBytes(String path, {Map<String, dynamic>? query}) async {
    final res = await _dio.get<List<int>>(
      path,
      queryParameters: query,
      options: Options(responseType: ResponseType.bytes),
    );
    return Uint8List.fromList(res.data ?? const <int>[]);
  }

  // POST
  static Future<dynamic> post(
    String path, {
    dynamic data,
    bool multipart = false,
    bool formUrlEncoded = false,
  }) async {
    final res = await _dio.post(
      path,
      data: data,
      options: multipart
          ? Options(contentType: 'multipart/form-data')
          : formUrlEncoded
              ? Options(contentType: Headers.formUrlEncodedContentType)
              : null,
    );
    return res.data;
  }

  // PATCH
  static Future<dynamic> patch(String path, {dynamic data}) async {
    final res = await _dio.patch(path, data: data);
    return res.data;
  }

  // DELETE
  static Future<dynamic> delete(String path, {Map<String, dynamic>? query}) async {
    final res = await _dio.delete(path, queryParameters: query);
    return res.data;
  }

  // simple wrapper, mirroring your Api.post/patch helpers
static Future<dynamic> put(String path, {dynamic data, Map<String, dynamic>? query}) async {
  final res = await _dio.put(path, data: data, queryParameters: query);
  return res.data;
}

}
