pluginManagement {
    // read flutter.sdk from local.properties
    val localPropsFile = java.io.File(settingsDir, "local.properties")
    if (!localPropsFile.exists()) {
        throw GradleException("local.properties not found at: ${localPropsFile.absolutePath}")
    }
    val props = java.util.Properties()
    localPropsFile.inputStream().use { props.load(it) }

    val sdk = props.getProperty("flutter.sdk")
        ?: throw GradleException("`flutter.sdk` not set in local.properties")

    includeBuild("$sdk/packages/flutter_tools/gradle")

    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        maven(url = "https://storage.googleapis.com/download.flutter.io")
    }
}

plugins {
    id("dev.flutter.flutter-plugin-loader")
}

include(":app")
